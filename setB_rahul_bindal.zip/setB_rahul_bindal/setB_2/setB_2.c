#include<stdio.h>
#include<string.h>
struct relation
{
	char child[10],father[10];
}s[10];

int countgrandchild (char b[],int n,int count)
{
	for(int i=0;i<n;i++)
	{
		if(strcmp(b,s[i].father)==0)
		{
			count++;
		}
	}
	return count;
} 
void main(){
	FILE *fp;
	int n,i=0,count=0;
	char a[20];
	fp=fopen("file.txt","r");
	while(!feof(fp))
	{
		fscanf(fp,"%s",s[i].child);
		fscanf(fp,"%s",s[i].father);
		i++;
		
		
	}
	n=i;
	for(i=0;i<5;i++)
	{
		printf("%s ",s[i].father);
		printf("%s\n",s[i].child);
	
	}	
	printf("Enter the input string for which you want to find granchild\n");
	scanf("%s",a);
	for(i=0;i<5;i++)
	{
		if(strcmp(a,s[i].father)==0)
		{
			count = countgrandchild(s[i].child,n,count);
		}
	}
	if(count>0)
	printf("Number of grandchildern for %s is %d",a,count);
	else
	printf("No grandchildern for %s",a);
	fclose(fp);
}